import java.io.Serializable;
import java.util.*;
import java.util.Scanner;
public class Bus implements Serializable {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	public int MSTuyen;

	public int getMSTuyen() {
		return MSTuyen;
	}

	public void setMSTuyen(int mSTuyen) {
		MSTuyen = mSTuyen;
	}

	public String HoTen;

	public String getHoTen() {
		return HoTen;
	}

	public void setHoTen(String hoTen) {
		HoTen = hoTen;
	}

	public int SoXe;

	public int getSoXe() {
		return SoXe;
	}

	public void setSoXe(int soXe) {
		SoXe = soXe;
	}

	public int DoanhThu;

	public int getDoanhThu() {
		return DoanhThu;
	}

	public void setDoanhThu(int doanhThu) {
		DoanhThu = doanhThu;
	}

	public Bus(int MSTuyen, String HoTen, int SoXe, int DoanhThu) {
		this.DoanhThu = DoanhThu;
		this.HoTen = HoTen;
		this.MSTuyen = MSTuyen;
		this.SoXe = SoXe;
	}
	public static void main(String[] args) {
		int numBer,total = 0;
	    Scanner input = new Scanner(System.in);
		System.out.println("시내 버스 노선 수를 입력하십시오");
		numBer=input.nextInt();
		List<Urban> urbans = new ArrayList<Urban>(); 
		for (int i = 0; i < numBer; i++) {
			Urban urban = new Urban(0, null, 0, 0, 0, 0);
			System.out.println("Nhap ma so tuyen");
			urban.MSTuyen=input.nextInt();
			System.out.println("Nhap ho ten");
			urban.HoTen= input.nextLine();
			input.nextLine();
			System.out.println("Nhap so xe");
			urban.SoXe=input.nextInt();
			System.out.println("Nhap so tuyen");
			urban.SoTuyen=input.nextInt();
			System.out.println("Nhap so KM");
			urban.SoKM=input.nextInt();
			System.out.println("Nhap doanh thu");
			urban.DoanhThu=input.nextInt();
			urbans.add(urban);
		}
		System.out.println("교외 버스 노선 목록을 입력하십시오");
		numBer=input.nextInt();
		List<Suburban> subUrbans = new ArrayList<Suburban>(); 
		for (int i = 0; i < numBer; i++) {
			Suburban subUrban = new Suburban(0, null, 0, 0, null, 0);
			System.out.println("Nhap ma so tuyen: ");
			subUrban.MSTuyen=input.nextInt();
			System.out.println("Nhap ho ten: ");
			subUrban.HoTen= input.nextLine();
			input.nextLine();
			System.out.println("Nhap so xe: ");
			subUrban.SoXe=input.nextInt();
			System.out.println("Nhap noi den: ");
			subUrban.NoiDen=input.nextLine();
			input.nextLine();
			System.out.println("Nhap so ngay: ");
			subUrban.SoNgay=input.nextInt();
			System.out.println("Nhap doanh thu: ");
			subUrban.DoanhThu=input.nextInt();
			subUrbans.add(subUrban);
		}
		System.out.println("........DS Tuyen Noi Thanh........");
		for (Urban urban : urbans) {
			System.out.println("So tuyen: "+urban.MSTuyen );
			System.out.println("Ho ten: " +urban.HoTen);
			System.out.println("So xe: " + urban.SoXe);
			System.out.println("So tuyen: "+ urban.SoTuyen);
			System.out.println("So KM: " + urban.SoKM);
			System.out.println("Doanh thu: " + urban.DoanhThu);
			total= urban.DoanhThu;
		}
		System.out.println("Tong Doanh Thu Tuyen Noi Thanh"+ total);
		System.out.println("........DS Tuyen Ngoai Thanh........");
		for (Suburban subUrban : subUrbans) {
			System.out.println("So tuyen: "+subUrban.MSTuyen );
			System.out.println("Ho ten: " +subUrban.HoTen);
			System.out.println("So xe: " + subUrban.SoXe);
			System.out.println("Noi den: "+ subUrban.NoiDen);
			System.out.println("So ngay: " + subUrban.SoNgay);
			System.out.println("Doanh thu: " + subUrban.DoanhThu);
			total= subUrban.DoanhThu;
		}
		System.out.println("Tong Doanh Thu Tuyen Ngoai Thanh"+ total);
	}
}
class Suburban extends Bus{
	public Suburban(int MSTuyen, String HoTen, int SoXe, int DoanhThu,String NoiDen,int SoNgay) {
		super(MSTuyen, HoTen, SoXe, DoanhThu);
		this.NoiDen=NoiDen;
		this.SoNgay=SoNgay;
		
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String NoiDen;
	public String getNoiDen() {
		return NoiDen;
	}
	public void setNoiDen(String noiDen) {
		NoiDen = noiDen;
	}
	public int SoNgay;
	public int getSoNgay() {
		return SoNgay;
	}
	public void setSoNgay(int soNgay) {
		SoNgay = soNgay;
	}
		
}
class Urban extends Bus{
	public Urban(int MSTuyen, String HoTen, int SoXe, int DoanhThu,int SoTuyen,int SoKM) {
		super(MSTuyen, HoTen, SoXe, DoanhThu);
		this.SoTuyen=SoTuyen;
		this.SoKM=SoKM;
		
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int SoTuyen;
	public int getSoTuyen() {
		return SoTuyen;
	}
	public void setSoTuyen(int soTuyen) {
		SoTuyen = soTuyen;
	}
	public int getSoKM() {
		return SoKM;
	}
	public void setSoKM(int soKM) {
		SoKM = soKM;
	}
	public int SoKM;
		
}

